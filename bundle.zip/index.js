var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// image optmization code here
let SITEID = "";
const imageConversionUrl = "https://8234-2409-40f3-100a-91e6-ad0e-cb3c-b765-c85b.ngrok-free.app/";
const authToken = "f48c0640be611f9137eaacf50459e0d38d092c690fbd12c89bcc53ce9fc4dab3";
let imageSize = 0;
let optimizedImageSize = 0;
// Helper function to make authenticated API requests
function makeAuthenticatedRequest(url, method, body = null) {
    return __awaiter(this, void 0, void 0, function* () {
        const headers = {
            accept: 'application/json',
            authorization: `Bearer ${authToken}`,
        };
        if (body) {
            headers['content-type'] = 'application/json';
        }
        const response = yield fetch(url, {
            method,
            headers,
            body: body ? JSON.stringify(body) : null,
        });
        if (!response.ok) {
            throw new Error(`Request failed with status ${response.status}`);
        }
        return response.json();
    });
}
// Helper function to calculate image size
function calculateImageSize(url) {
    return __awaiter(this, void 0, void 0, function* () {
        const imageFetch = yield fetch(url);
        const blob = yield imageFetch.blob();
        return blob.size;
    });
}
// Helper function to convert an image to WebP and calculate optimized size
function optimizeImage(imageUrl) {
    return __awaiter(this, void 0, void 0, function* () {
        const webpImageUrl = yield makeAuthenticatedRequest(imageConversionUrl, 'POST', {
            image_url: imageUrl,
        });
        const optimizedImageFetch = yield fetch(webpImageUrl.image_url);
        const optimizedBlob = yield optimizedImageFetch.blob();
        const optimizedSize = optimizedBlob.size;
        return { webpImageUrl: webpImageUrl.image_url, optimizedSize };
    });
}
// Function to fetch collections and process items
function processCollectionsAndItems() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Fetch collections
            const collectionsResponse = yield makeAuthenticatedRequest(`https://api.webflow.com/beta/sites/${SITEID}/collections`, 'GET');
            const collections = collectionsResponse.collections;
            for (const collection of collections) {
                const itemID = collection.id;
                // Fetch collection items
                const itemsResponse = yield makeAuthenticatedRequest(`https://api.webflow.com/beta/collections/${itemID}/items`, 'GET');
                const items = itemsResponse.items;
                // Process items
                for (const item of items) {
                    const imageUrl = item.fieldData.image.url;
                    console.log('image url', imageUrl);
                    // Calculate image size
                    const originalSize = yield calculateImageSize(imageUrl);
                    imageSize += originalSize;
                    // Optimize image and calculate optimized size
                    const { webpImageUrl, optimizedSize } = yield optimizeImage(imageUrl);
                    optimizedImageSize += optimizedSize;
                    console.log('webp url', webpImageUrl);
                    console.log('result', imageSize, optimizedImageSize, formatBytes(optimizedImageSize), formatBytes(imageSize));
                    // document.getElementById('optimizeBtn').innerText = 'Optimize Image'
                    document.getElementById('optimizeBtn').innerText = 'Optimize Image';
                    document.getElementById('result').innerText = `${webpImageUrl} - ${imageUrl}`;
                }
            }
        }
        catch (err) {
            console.error('error:', err);
        }
    });
}
function formatBytes(bytes) {
    if (bytes < 1024) {
        return bytes + " B";
    }
    else if (bytes < 1048576) { // 1024 * 1024
        return (bytes / 1024).toFixed(2) + " KB";
    }
    else {
        return (bytes / 1048576).toFixed(2) + " MB";
    }
}
document.getElementById("lorem").onsubmit = (event) => __awaiter(this, void 0, void 0, function* () {
    event.preventDefault();
    // const el = await webflow.getSelectedElement();
    const siteInfo = yield webflow.getSiteInfo();
    console.log(siteInfo.siteId);
    SITEID = siteInfo.siteId;
    document.getElementById('optimizeBtn').innerText = 'Loading!..';
    // fetch(`https://api.webflow.com/beta/sites/${SITEID}/collections`,  {
    //   method: 'GET',
    //   headers: {
    //     accept: 'application/json',
    //     authorization: 'Bearer f48c0640be611f9137eaacf50459e0d38d092c690fbd12c89bcc53ce9fc4dab3'
    //   }
    // }).then(response => response.json()).then(collections => {
    //   console.log(collections);
    //   document.getElementById('result').innerText = collections.collections[0].id
    // }).catch(err => {
    //   console.log(err);
    //   document.getElementById('result').innerText = err
    // })
    // processCollectionsAndItems();
    fetch("https://api.webflow.com/beta/sites/64fcac6248f37162d247f6e5/collections", {
        method: 'GET',
        headers: {
            "accept-encoding": "gzip, deflate, br",
            "Accept": "*/*",
            "User-Agent": "Thunder Client (https://www.thunderclient.com)",
            "Authorization": "Bearer f48c0640be611f9137eaacf50459e0d38d092c690fbd12c89bcc53ce9fc4dab3"
        }
    }).then(response => response.json()).then(todo => {
        document.getElementById('result').innerText = todo.title;
    }).catch(err => {
        document.getElementById('result').innerText = err;
    });
    document.getElementById('status').innerText = `Image optimized from ${formatBytes(imageSize)} to ${formatBytes(optimizedImageSize)}.`;
    // if (el && el.textContent) {
    //   el.setTextContent(
    //     'Image Optimized Successfully'
    //   )
    //   el.save()
    // }
});
